# Dictivo local-engine sample: human-read English, 12 September 2026

This vendor-run example uses the CLI bundled with **Dictivo 0.3.47** (whisper.cpp **v1.8.4**) on an **Apple M4 Pro, 48 GB memory, macOS 26.3.1 (a)**. Metal acceleration was confirmed in an additional diagnostic invocation. The Mac was on battery power, at 78% when the test started.

The input is **25.3123125 seconds**, including **one second of added silence**. It joins the original human recordings **p225_001–005** from CSTR VCTK v0.92 in their original order, with 250 ms of silence between sentences. The five source recordings contain 24.3123125 seconds of audio. This is a reconstructed read paragraph, **not one continuous recording or spontaneous dictation**. The source speech was not synthesized, cloned, sped up, pitch-shifted, denoised, or mixed with music. Original FLAC files were decoded and resampled to 16 kHz, mono, 16-bit PCM.

| Installed model | Measured CLI runs | Median | Normalized word errors |
| --- | --- | --- | --- |
| Small | 1.0624 s, 1.0623 s, 1.0544 s | **1.0623 s** | **0 / 69** on this sample |
| Large v3 Turbo Q5_0 | 2.0666 s, 2.0663 s, 2.0684 s | **2.0666 s** | **0 / 69** on this sample |

Every measured run produced the same words for both models. The engine omitted two commas present in the reference. The word-error count ignores capitalization and punctuation; it is **not a claim of a perfectly identical transcript or general 100% accuracy**.

## Procedure and timing boundary

One full invocation per model served as a warmup and is excluded from the table. Three measured runs per model then started fresh CLI processes in an interleaved order. Timing uses `time.perf_counter()` immediately before `subprocess.run()` until the CLI process exits. It includes process startup, model loading, decoding, and writing the output text. The operating system's file caches may already be warm. This is not a persistent preloaded-model measurement.

The command matches the application's **Balanced profile with language Auto and no initial prompt**:

```sh
"$ENGINE" -m "$MODEL" -f "$INPUT" -l auto -otxt -of "$OUTPUT_STEM" \
  -np -nt --temperature 0 --suppress-nst -bo 3 -bs 3 -mc 160 -sow -ml 80
```

`ENGINE` is the `whisper-cli` shipped inside the macOS app. `MODEL` is an installed model file, and `INPUT` is the WAV included here. Threads were left at the CLI default of four, as in the application command builder. This test uses the CLI directly; it excludes microphone capture, frontend audio handling, application IPC, app-side cleanup, and inserting text into the destination app. **It is not a full-app end-to-end latency measurement.**

`all-runs.json` retains warmups, measured runs, exact commands, wall times, outputs, and word-error comparisons. `environment.json` and `input-manifest.json` retain versions, parameters, input and model hashes, and source provenance. Diagnostic runs remove only `-np` to reveal backend initialization and are excluded from timing.

## Limits

This is one clean English read-speech example from one speaker, on one computer, run by Dictivo. The sample was selected before either model was run. It is shorter than a 30-second Whisper window and does not test long recordings, noisy microphones, spontaneous speech, other languages, other hardware, or Windows. Training overlap with the public dataset or this familiar passage is unknown; this is not a verified held-out evaluation. Three timing repetitions in an ordinary desktop session cannot establish performance guarantees. No other product was tested, and these results support no competitor superiority claim.

No audio upload or cloud API is used by the test script. The network was not disabled or inspected during this timing experiment, so the benchmark itself is **not network-privacy proof**.

## Attribution

Source: Junichi Yamagishi, Christophe Veaux, and Kirsten MacDonald (2019), *CSTR VCTK Corpus: English Multi-speaker Corpus for CSTR Voice Cloning Toolkit, version 0.92*. University of Edinburgh, Centre for Speech Technology Research. [Dataset and DOI](https://doi.org/10.7488/ds/2645). Licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/); the license and original README are included. The edits are the resampling and concatenation described above. No endorsement by the speakers, dataset authors, or university is implied.

## Appropriate website wording

> Hear the input and read the actual local-engine output. In this 25-second, five-utterance English example, the Small model completed the CLI run in a median 1.06 seconds and Turbo Q5 in 2.07 seconds on an M4 Pro with 48 GB memory. Both preserved the 69 reference words after case and punctuation normalization. Results vary with your speech, model, and computer; this measures the local engine, not the complete dictation workflow.

Keep the reconstruction disclosure adjacent to the audio player. Use this as an inspectable example under the existing benchmark method, not as a new broad “accuracy” landing page. Retain the input, actual output, timing boundary, version, and attribution links together.
