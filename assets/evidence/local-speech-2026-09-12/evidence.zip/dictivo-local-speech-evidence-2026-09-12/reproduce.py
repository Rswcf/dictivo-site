"""Replay the supplied WAV with installed model files; writes only ./reproduced/.

Optional environment variables: DICTIVO_BENCH_ENGINE and DICTIVO_BENCH_MODELS.
No model downloads, cloud calls, app settings, or recording history are used.
"""
import hashlib
import json
import os
import re
import statistics
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parent
engine = Path(os.environ.get("DICTIVO_BENCH_ENGINE", "/Applications/Dictivo.app/Contents/Resources/private-fast/bin/whisper-cli"))
models = Path(os.environ.get("DICTIVO_BENCH_MODELS", str(Path.home() / "Library/Application Support/Dictivo/private-fast/models")))
input_file = root / "input/vctk-p225-five-utterances-16k.wav"
reference = (root / "input/reference.txt").read_text()
target = root / "reproduced"
target.mkdir(exist_ok=True)


def normalize(text):
    return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", text.lower().replace("’", "'"))


def errors(a, b):
    row = list(range(len(b) + 1))
    for i, word in enumerate(a, 1):
        next_row = [i]
        for j, other in enumerate(b, 1):
            next_row.append(min(next_row[-1] + 1, row[j] + 1, row[j - 1] + (word != other)))
        row = next_row
    return row[-1]


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


ids = ["small", "large-v3-turbo-q5_0"]
for model_id in ids:
    assert (models / f"ggml-{model_id}.bin").is_file(), f"Install model first: {model_id}"
assert engine.is_file(), "Set DICTIVO_BENCH_ENGINE to an installed whisper-cli binary"
provenance = {"engine_sha256": sha256(engine), "input_sha256": sha256(input_file),
              "models": {i: sha256(models / f"ggml-{i}.bin") for i in ids}}
(target / "hashes.json").write_text(json.dumps(provenance, indent=2) + "\n")

sequence = [(ids[0], 0), (ids[1], 0), (ids[0], 1), (ids[1], 1),
            (ids[1], 2), (ids[0], 2), (ids[0], 3), (ids[1], 3)]
runs = []
for model_id, repetition in sequence:
    stem = target / f"{model_id}-{repetition}"
    command = [str(engine), "-m", str(models / f"ggml-{model_id}.bin"), "-f", str(input_file),
               "-l", "auto", "-otxt", "-of", str(stem), "-np", "-nt", "--temperature", "0",
               "--suppress-nst", "-bo", "3", "-bs", "3", "-mc", "160", "-sow", "-ml", "80"]
    before = time.perf_counter()
    process = subprocess.run(command, capture_output=True, text=True, timeout=120)
    seconds = time.perf_counter() - before
    stem.with_suffix(".stderr.txt").write_text(process.stderr)
    stem.with_suffix(".stdout.txt").write_text(process.stdout)
    output = " ".join(stem.with_suffix(".txt").read_text().split()) if stem.with_suffix(".txt").exists() else ""
    run = {"model": model_id, "repetition": repetition, "warmup": repetition == 0,
           "wall_seconds": seconds, "exit_code": process.returncode, "command": command,
           "output": output, "reference_words": len(normalize(reference)),
           "word_errors": errors(normalize(reference), normalize(output))}
    runs.append(run)
    (target / "runs.json").write_text(json.dumps(runs, indent=2) + "\n")
    print(f"{model_id}, repetition {repetition}: {seconds:.4f} s, {run['word_errors']} word errors", flush=True)
    if process.returncode:
        raise RuntimeError(f"Engine exited {process.returncode}; inspect retained stderr")
for model_id in ids:
    measured = [r["wall_seconds"] for r in runs if r["model"] == model_id and not r["warmup"]]
    print(f"{model_id}: median {statistics.median(measured):.4f} s, range {min(measured):.4f}–{max(measured):.4f} s")
